const config = {
  //Config shit here.
    apiKey: "AIzaSyAxAbAcQ4sKpHjYjV7zNoBIRWvHsk_1YWE",
    authDomain: "geo-coffee-1531775375192.firebaseapp.com",
    databaseURL: "https://geo-coffee-1531775375192.firebaseio.com",
    projectId: "geo-coffee-1531775375192",
    storageBucket: "",
    messagingSenderId: "532193946214"
}

export default config;
